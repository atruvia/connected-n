package org.ase.fourwins.client.udphelper;

public interface MessageListener {
	
	void onMessage(String message);
	
}
